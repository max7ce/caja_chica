import { supabase } from './supabase'
import type {
  Categoria, Comprobante, InformeRendicion, MovimientoCaja, Notificacion, Oficina, Parametros,
  Periodo, Profile, RendicionAdmin, Rol, SaldoCaja, Solicitud, TipoComprobante
} from '../types/database'

const SEL_SOL =
  '*, solicitante:profiles!solicitudes_solicitante_id_fkey(id, full_name, email, departamento, qr_url)'

/* ---------------------------------------------------------------- básicos */

export async function obtenerParametros(): Promise<Parametros> {
  const { data, error } = await supabase.from('parametros').select('*').eq('id', 1).single()
  if (error) throw error
  return data as Parametros
}

export async function guardarParametros(cambios: Partial<Parametros>) {
  const { error } = await supabase.from('parametros').update(cambios).eq('id', 1)
  if (error) throw error
}

export async function obtenerPerfil(id: string): Promise<Profile | null> {
  const { data, error } = await supabase.from('profiles').select('*').eq('id', id).maybeSingle()
  if (error) throw error
  return data
}

export async function listarPerfiles(): Promise<Profile[]> {
  const { data, error } = await supabase.from('profiles').select('*').order('full_name')
  if (error) throw error
  return data ?? []
}

export async function actualizarPerfil(id: string, cambios: Partial<Profile>) {
  const { error } = await supabase.from('profiles').update(cambios).eq('id', id)
  if (error) throw error
}

export async function cambiarRol(id: string, role: Rol) {
  const { error } = await supabase.from('profiles').update({ role }).eq('id', id)
  if (error) throw error
}

/* --------------------------------------------------------------- períodos */

export async function listarPeriodos(): Promise<Periodo[]> {
  const { data, error } = await supabase
    .from('periodos_gestion')
    .select('*, admin:profiles!periodos_gestion_admin_caja_id_fkey(id, full_name)')
    .order('fecha_inicio', { ascending: false })
  if (error) throw error
  return (data ?? []) as Periodo[]
}

export async function periodoVigente(): Promise<Periodo | null> {
  const { data, error } = await supabase
    .from('periodos_gestion')
    .select('*, admin:profiles!periodos_gestion_admin_caja_id_fkey(id, full_name)')
    .eq('estado', 'vigente')
    .maybeSingle()
  if (error) throw error
  return data as Periodo | null
}

/** Cierra la gestión vigente y abre la nueva. El índice único impide que haya dos. */
export async function rotarPeriodo(adminCajaId: string, etiqueta: string, fondo: number) {
  const vigente = await periodoVigente()
  if (vigente) {
    const { error } = await supabase
      .from('periodos_gestion')
      .update({ estado: 'cerrado', fecha_fin: new Date().toISOString() })
      .eq('id', vigente.id)
    if (error) throw error
  }
  const { error } = await supabase
    .from('periodos_gestion')
    .insert({ admin_caja_id: adminCajaId, etiqueta, fondo_asignado: fondo })
  if (error) throw error
}

/* ------------------------------------------------------------ solicitudes */

export async function listarSolicitudes(filtros?: { estado?: string; solicitanteId?: string }) {
  let q = supabase.from('solicitudes').select(SEL_SOL).order('fecha_creacion', { ascending: false })
  if (filtros?.estado) q = q.eq('estado', filtros.estado)
  if (filtros?.solicitanteId) q = q.eq('solicitante_id', filtros.solicitanteId)
  const { data, error } = await q
  if (error) throw error
  return (data ?? []) as Solicitud[]
}

export async function obtenerSolicitud(id: string): Promise<Solicitud | null> {
  const { data, error } = await supabase.from('solicitudes').select(SEL_SOL).eq('id', id).maybeSingle()
  if (error) throw error
  return data as Solicitud | null
}

/** true si el usuario tiene una rendición pasada de plazo (bloquea vales nuevos). */
export async function tieneRendicionVencida(usuarioId: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('solicitudes')
    .select('id, limite_tiempo_devolucion')
    .eq('solicitante_id', usuarioId)
    .in('estado', ['desembolsado', 'pendiente_devolucion'])
    .lt('limite_tiempo_devolucion', new Date().toISOString())
  if (error) throw error
  return (data ?? []).length > 0
}

export async function crearSolicitud(entrada: {
  solicitante_id: string
  monto_solicitado: number
  descripcion: string
  categoria: string | null
}) {
  const { data, error } = await supabase.from('solicitudes').insert(entrada).select('id').single()
  if (error) throw error
  return data.id as string
}

export async function decidirSolicitud(id: string, dafId: string, aprobar: boolean, motivo?: string) {
  const { error } = await supabase
    .from('solicitudes')
    .update({
      estado: aprobar ? 'aprobado_daf' : 'rechazado',
      aprobado_por_id: dafId,
      origen_decision: 'app',
      motivo_rechazo: aprobar ? null : motivo ?? null
    })
    .eq('id', id)
  if (error) throw error

  if (!aprobar) {
    const { data: s } = await supabase.from('solicitudes').select('solicitante_id').eq('id', id).single()
    if (s) await agendarAviso('solicitud_rechazada', 'correo', s.solicitante_id, id, { motivo: motivo ?? '' })
  }
}

/** El trigger de la base calcula el vencimiento hábil y agenda los recordatorios. */
export async function desembolsar(solicitud: Solicitud, adminCajaId: string, periodoId: string | null) {
  const { error: e1 } = await supabase
    .from('solicitudes')
    .update({ estado: 'desembolsado', admin_caja_id: adminCajaId })
    .eq('id', solicitud.id)
  if (e1) throw e1

  const { error: e2 } = await supabase.from('movimientos_caja').insert({
    tipo: 'desembolso',
    monto: solicitud.monto_solicitado,
    solicitud_id: solicitud.id,
    periodo_id: periodoId,
    admin_caja_id: adminCajaId,
    registrado_por_id: adminCajaId,
    descripcion: solicitud.descripcion,
    estado: 'aprobado',
    aprobado_por_id: adminCajaId
  })
  if (e2) throw e2
}

/**
 * El solicitante declara el gasto. Nunca cierra la solicitud: si no hay
 * diferencia que devolver, queda esperando que el administrador reciba y
 * coteje los documentos físicos.
 */
export async function reportarGasto(solicitud: Solicitud, montoReal: number) {
  const hayDiferencia = montoReal < Number(solicitud.monto_solicitado)
  const { error } = await supabase
    .from('solicitudes')
    .update({
      monto_real: montoReal,
      fecha_rendicion: new Date().toISOString(),
      estado: hayDiferencia ? 'pendiente_devolucion' : 'pendiente_verificacion'
    })
    .eq('id', solicitud.id)
  if (error) throw error
  return hayDiferencia
}

/* ---------------------------------------------------------- comprobantes */

export async function subirComprobante(o: {
  archivo: File; solicitudId: string; tipo: TipoComprobante; usuarioId: string; descripcion?: string
}): Promise<string> {
  const ext = o.archivo.name.split('.').pop()?.toLowerCase() ?? 'pdf'
  const ruta = `solicitud-${o.solicitudId}/${o.tipo}-${Date.now()}.${ext}`

  const { error: e1 } = await supabase.storage.from('comprobantes').upload(ruta, o.archivo)
  if (e1) throw e1

  const { error: e2 } = await supabase.from('comprobantes').insert({
    solicitud_id: o.solicitudId, archivo_url: ruta, tipo: o.tipo,
    descripcion: o.descripcion ?? null, subido_por_id: o.usuarioId
  })
  if (e2) throw e2
  return ruta
}

export function urlPublica(ruta: string): string {
  return supabase.storage.from('comprobantes').getPublicUrl(ruta).data.publicUrl
}

export async function listarComprobantes(solicitudId: string): Promise<Comprobante[]> {
  const { data, error } = await supabase
    .from('comprobantes').select('*').eq('solicitud_id', solicitudId).order('fecha_subida')
  if (error) throw error
  return data ?? []
}

/* ------------------------------------------------- devoluciones y saldo */

export async function registrarDevolucion(o: {
  solicitudId: string; monto: number; rutaComprobante: string; usuarioId: string; periodoId: string | null
}) {
  const { error } = await supabase.from('movimientos_caja').insert({
    tipo: 'devolucion', monto: o.monto, solicitud_id: o.solicitudId, periodo_id: o.periodoId,
    registrado_por_id: o.usuarioId, comprobante_url: o.rutaComprobante,
    descripcion: 'Devolución de diferencia por QR', estado: 'pendiente_validacion'
  })
  if (error) throw error
}

export async function listarMovimientos(filtros?: { estado?: string; solicitudId?: string }) {
  let q = supabase
    .from('movimientos_caja')
    .select('*, solicitud:solicitudes(id, descripcion, monto_solicitado, solicitante_id)')
    .order('created_at', { ascending: false })
  if (filtros?.estado) q = q.eq('estado', filtros.estado)
  if (filtros?.solicitudId) q = q.eq('solicitud_id', filtros.solicitudId)
  const { data, error } = await q
  if (error) throw error
  return (data ?? []) as MovimientoCaja[]
}

export async function validarDevolucion(m: MovimientoCaja, adminCajaId: string) {
  const { error: e1 } = await supabase
    .from('movimientos_caja')
    .update({ estado: 'aprobado', aprobado_por_id: adminCajaId, admin_caja_id: adminCajaId })
    .eq('id', m.id)
  if (e1) throw e1

  if (m.solicitud_id) {
    // Validado el depósito, todavía falta el cotejo del físico.
    const { error: e2 } = await supabase
      .from('solicitudes').update({ estado: 'pendiente_verificacion' }).eq('id', m.solicitud_id)
    if (e2) throw e2
    await agendarAviso('devolucion_validada', 'whatsapp', m.solicitud!.solicitante_id, m.solicitud_id, {
      monto: m.monto
    })
  }
}

export async function obtenerSaldo(periodoId: string | null): Promise<SaldoCaja> {
  // La vista devuelve una fila por período: sin período fijado hay que sumarlas.
  let q = supabase.from('v_saldo_caja').select('*')
  if (periodoId) q = q.eq('periodo_id', periodoId)
  const { data, error } = await q
  if (error) throw error

  const filas = (data ?? []) as SaldoCaja[]
  return filas.reduce<SaldoCaja>((acc, f) => ({
    periodo_id: periodoId,
    saldo: acc.saldo + Number(f.saldo),
    total_desembolsado: acc.total_desembolsado + Number(f.total_desembolsado),
    total_devuelto: acc.total_devuelto + Number(f.total_devuelto),
    total_repuesto: acc.total_repuesto + Number(f.total_repuesto)
  }), { periodo_id: periodoId, saldo: 0, total_desembolsado: 0, total_devuelto: 0, total_repuesto: 0 })
}

/* --------------------------------------------------- rendición de cuentas */

export async function solicitudesSinRendir(): Promise<Solicitud[]> {
  const { data: rendidas, error: e1 } = await supabase.from('informe_solicitudes').select('solicitud_id')
  if (e1) throw e1
  const ids = (rendidas ?? []).map((r) => r.solicitud_id)

  let q = supabase.from('solicitudes').select(SEL_SOL)
    .in('estado', ['completado', 'pendiente_devolucion']).order('fecha_desembolso')
  if (ids.length) q = q.not('id', 'in', `(${ids.join(',')})`)

  const { data, error } = await q
  if (error) throw error
  return (data ?? []) as Solicitud[]
}

export async function crearInforme(o: {
  adminCajaId: string; periodoId: string | null; solicitudes: Solicitud[]
  observaciones: string; montoReposicion: number
}): Promise<string> {
  const totalDesembolsado = o.solicitudes.reduce((s, x) => s + Number(x.monto_solicitado), 0)
  const totalDevuelto = o.solicitudes.reduce(
    (s, x) => s + Math.max(Number(x.monto_solicitado) - Number(x.monto_real ?? x.monto_solicitado), 0), 0)
  const fechas = o.solicitudes.map((s) => new Date(s.fecha_creacion).getTime())
  const saldo = await obtenerSaldo(o.periodoId)

  const { data, error } = await supabase.from('informe_rendicion_cuentas').insert({
    periodo_id: o.periodoId,
    admin_caja_id: o.adminCajaId,
    monto_reposicion: o.montoReposicion,
    fecha_inicio_periodo: fechas.length ? new Date(Math.min(...fechas)).toISOString() : null,
    fecha_fin_periodo: fechas.length ? new Date(Math.max(...fechas)).toISOString() : null,
    estado: 'pendiente_daf',
    fecha_envio_daf: new Date().toISOString(),
    total_desembolsado: totalDesembolsado,
    total_devuelto: totalDevuelto,
    saldo_cuenta: saldo.saldo,
    observaciones: o.observaciones
  }).select('id').single()
  if (error) throw error

  const { error: e2 } = await supabase.from('informe_solicitudes')
    .insert(o.solicitudes.map((s) => ({ informe_id: data.id, solicitud_id: s.id })))
  if (e2) throw e2

  const { data: dafs } = await supabase.from('profiles').select('id').eq('role', 'daf').eq('activo', true)
  for (const d of dafs ?? []) {
    await agendarAviso('informe_enviado', 'correo', d.id, data.id, { monto: totalDesembolsado }, 'informe')
  }
  return data.id as string
}

export async function listarInformes(): Promise<InformeRendicion[]> {
  const { data, error } = await supabase
    .from('informe_rendicion_cuentas').select('*').order('fecha_creacion', { ascending: false })
  if (error) throw error
  return data ?? []
}

export async function obtenerInforme(id: string) {
  const { data, error } = await supabase
    .from('informe_rendicion_cuentas').select('*').eq('id', id).maybeSingle()
  if (error) throw error

  const { data: rel, error: e2 } = await supabase
    .from('informe_solicitudes').select(`solicitud:solicitudes(${SEL_SOL})`).eq('informe_id', id)
  if (e2) throw e2

  // Contabilidad necesita el QR del administrador para transferirle la reposición.
  let admin: Profile | null = null
  if (data?.admin_caja_id) {
    const { data: p } = await supabase
      .from('profiles').select('*').eq('id', data.admin_caja_id).maybeSingle()
    admin = p as Profile | null
  }

  return {
    informe: data as InformeRendicion | null,
    solicitudes: (rel ?? []).map((r: any) => r.solicitud as Solicitud),
    admin
  }
}

export async function resolverInforme(informe: InformeRendicion, aprobado: boolean, dafId: string) {
  const { error } = await supabase.from('informe_rendicion_cuentas').update({
    estado: aprobado ? 'aprobado_daf' : 'rechazado',
    fecha_aprobacion_daf: new Date().toISOString(),
    aprobado_por_id: dafId
  }).eq('id', informe.id)
  if (error) throw error

  // El administrador se entera del resultado; contabilidad solo si se aprobó,
  // porque recién ahí tienen algo que hacer.
  await agendarAviso('informe_aprobado', 'correo', informe.admin_caja_id, informe.id,
    { estado: aprobado ? 'aprobado' : 'rechazado' }, 'informe')

  if (aprobado) {
    const { data: contables } = await supabase
      .from('profiles').select('id').eq('role', 'contabilidad').eq('activo', true)
    for (const c of contables ?? []) {
      await agendarAviso('reposicion_por_procesar', 'correo', c.id, informe.id,
        { monto: informe.monto_reposicion }, 'informe')
    }
  }
}

export async function registrarReposicion(informe: InformeRendicion, adminCajaId: string) {
  const { error: e1 } = await supabase.from('movimientos_caja').insert({
    tipo: 'reposicion', monto: informe.monto_reposicion, informe_id: informe.id,
    periodo_id: informe.periodo_id, admin_caja_id: adminCajaId, registrado_por_id: adminCajaId,
    descripcion: 'Reposición de caja chica por contabilidad',
    estado: 'aprobado', aprobado_por_id: adminCajaId
  })
  if (e1) throw e1

  const { error: e2 } = await supabase
    .from('informe_rendicion_cuentas').update({ estado: 'completado' }).eq('id', informe.id)
  if (e2) throw e2

  await agendarAviso('reposicion_hecha', 'ambos', informe.admin_caja_id, informe.id,
    { monto: informe.monto_reposicion }, 'informe')
}

/* -------------------------------------------------- reporte para el DAF */

export async function rendicionesPorAdmin(): Promise<RendicionAdmin[]> {
  const { data, error } = await supabase.from('v_rendiciones_por_admin').select('*')
  if (error) throw error
  return (data ?? []) as RendicionAdmin[]
}

/* ------------------------------------------------------------- avisos */

export async function agendarAviso(
  plantilla: string,
  canal: 'whatsapp' | 'correo' | 'ambos',
  destinatarioId: string,
  recursoId: string,
  variables: Record<string, unknown> = {},
  recursoTipo: 'solicitud' | 'informe' = 'solicitud',
  programadaPara?: string
) {
  const { error } = await supabase.from('notificaciones').insert({
    plantilla, canal, destinatario_id: destinatarioId,
    recurso_tipo: recursoTipo, recurso_id: recursoId,
    variables, programada_para: programadaPara ?? new Date().toISOString()
  })
  if (error) console.error('No se pudo agendar el aviso', error)
}

export async function listarAvisos(recursoId?: string): Promise<Notificacion[]> {
  let q = supabase.from('notificaciones').select('*').order('programada_para', { ascending: false }).limit(50)
  if (recursoId) q = q.eq('recurso_id', recursoId)
  const { data, error } = await q
  if (error) throw error
  return (data ?? []) as Notificacion[]
}

/* ------------------------------------------------------------- oficinas */

export async function listarOficinas(): Promise<Oficina[]> {
  const { data, error } = await supabase
    .from('oficinas')
    .select('*, coordinador:profiles!oficinas_coordinador_id_fkey(id, full_name, email)')
    .order('nombre')
  if (error) throw error
  return (data ?? []) as Oficina[]
}

/** Crea la oficina si no existe y devuelve su id. */
export async function asegurarOficina(nombre: string): Promise<string> {
  const limpio = nombre.trim().toUpperCase()
  const { data: existente } = await supabase
    .from('oficinas').select('id').eq('nombre', limpio).maybeSingle()
  if (existente) return existente.id as string

  const { data, error } = await supabase
    .from('oficinas').insert({ nombre: limpio }).select('id').single()
  if (error) throw error
  return data.id as string
}

export async function asignarCoordinador(oficinaId: string, coordinadorId: string | null) {
  const { error } = await supabase
    .from('oficinas').update({ coordinador_id: coordinadorId }).eq('id', oficinaId)
  if (error) throw error
}

export async function obtenerPerfilPorEmail(email: string): Promise<Profile | null> {
  const { data, error } = await supabase
    .from('profiles').select('*').eq('email', email.toLowerCase()).maybeSingle()
  if (error) throw error
  return data as Profile | null
}

/** Oficinas que coordina el usuario actual. Vacío si no coordina ninguna. */
export async function misOficinas(usuarioId: string): Promise<Oficina[]> {
  const { data, error } = await supabase
    .from('oficinas').select('*').eq('coordinador_id', usuarioId).eq('activa', true)
  if (error) throw error
  return (data ?? []) as Oficina[]
}

/* ---------------------------------------------------------------- aval */

/**
 * Dictamen del coordinador. Avale o no, la solicitud pasa al DAF: el trigger
 * de la base se encarga de avisarle con la observación incluida.
 */
export async function avalarSolicitud(
  solicitudId: string, avala: boolean, observacion: string
) {
  const { error } = await supabase.from('solicitudes').update({
    aval_coordinador: avala,
    observacion_coordinador: observacion.trim() || null,
    fecha_aval_coordinador: new Date().toISOString(),
    origen_aval: 'app',
    estado: 'pendiente_daf'
  }).eq('id', solicitudId).eq('estado', 'pendiente_coordinador')
  if (error) throw error
}

/* ------------------------------------------------------------ QR de cobro */

/**
 * Guarda el QR de cobro. La ruta empieza con el id del usuario porque la
 * política de Storage exige que cada quien escriba solo en su carpeta: así
 * nadie puede reemplazar el QR ajeno y desviarse un desembolso.
 */
export async function subirQR(archivo: File, usuarioId: string): Promise<string> {
  const ext = archivo.name.split('.').pop()?.toLowerCase() ?? 'png'
  const ruta = `${usuarioId}/qr-${Date.now()}.${ext}`
  const { error } = await supabase.storage.from('qr').upload(ruta, archivo, { upsert: true })
  if (error) throw error
  return ruta
}

export function urlQR(ruta: string | null | undefined): string | null {
  if (!ruta) return null
  return supabase.storage.from('qr').getPublicUrl(ruta).data.publicUrl
}

/* ------------------------------------------- restablecer contraseña */

/** Contraseña inicial legible, del mismo estilo que las de la importación. */
export function generarPassword(): string {
  const silabas = ['ka', 'mi', 'to', 'ru', 'pe', 'la', 'so', 'ne', 'vi', 'da']
  const a = silabas[Math.floor(Math.random() * silabas.length)]
  const b = silabas[Math.floor(Math.random() * silabas.length)]
  return `${a}${b}${Math.floor(1000 + Math.random() * 9000)}`
}

/**
 * Pide a la función de servidor que cambie la contraseña de otra persona.
 * El navegador nunca ve la llave de servicio: manda el token de la sesión
 * actual y el servidor verifica que sea super_admin.
 */
export async function restablecerPassword(usuarioId: string, password: string) {
  const { data: { session } } = await supabase.auth.getSession()
  if (!session) throw new Error('No hay sesión activa')

  const r = await fetch('/.netlify/functions/admin-usuarios', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${session.access_token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ usuarioId, password })
  })

  const cuerpo = await r.json().catch(() => ({}))
  if (!r.ok) throw new Error(cuerpo.error ?? `Error ${r.status}`)
  return cuerpo as { ok: true; email: string; nombre: string | null }
}

/* ---------------------------------------------------------- categorías */

export async function listarCategorias(soloActivas = false): Promise<Categoria[]> {
  let q = supabase.from('categorias').select('*').order('orden').order('nombre')
  if (soloActivas) q = q.eq('activa', true)
  const { data, error } = await q
  if (error) throw error
  return (data ?? []) as Categoria[]
}

export async function crearCategoria(nombre: string, orden: number) {
  const { error } = await supabase
    .from('categorias').insert({ nombre: nombre.trim(), orden })
  if (error) throw error
}

export async function actualizarCategoria(id: string, cambios: Partial<Categoria>) {
  const { error } = await supabase.from('categorias').update(cambios).eq('id', id)
  if (error) throw error
}

/* --------------------------------------------- verificación física */

/**
 * Cotejo de la documentación física contra lo cargado en el sistema.
 *
 * Conforme cierra la solicitud. No conforme la deja abierta con la
 * observación a la vista del solicitante, que debe corregir y volver a
 * presentar los papeles.
 */
export async function verificarFisica(
  solicitudId: string, conforme: boolean, observacion: string, adminId: string
) {
  const { error } = await supabase.from('solicitudes').update({
    conforme_fisica: conforme,
    observacion_fisica: observacion.trim() || null,
    fecha_recepcion_fisica: new Date().toISOString(),
    verificado_por_id: adminId,
    ...(conforme ? { estado: 'completado' } : {})
  }).eq('id', solicitudId).eq('estado', 'pendiente_verificacion')
  if (error) throw error
}

/* ------------------------------------------------- notificaciones push */

/** La clave VAPID viene en base64url y el navegador la pide como bytes. */
function base64UrlABytes(base64: string): ArrayBuffer {
  const relleno = '='.repeat((4 - (base64.length % 4)) % 4)
  const normal = (base64 + relleno).replace(/-/g, '+').replace(/_/g, '/')
  const crudo = atob(normal)
  const bytes = new Uint8Array(crudo.length)
  for (let i = 0; i < crudo.length; i++) bytes[i] = crudo.charCodeAt(i)
  return bytes.buffer
}

export function pushDisponible(): boolean {
  return 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window
}

export async function estadoPush(): Promise<'sin-soporte' | 'bloqueado' | 'activo' | 'inactivo'> {
  if (!pushDisponible()) return 'sin-soporte'
  if (Notification.permission === 'denied') return 'bloqueado'
  const reg = await navigator.serviceWorker.getRegistration()
  const sub = await reg?.pushManager.getSubscription()
  return sub ? 'activo' : 'inactivo'
}

/**
 * Activa las notificaciones en ESTE dispositivo. Cada navegador genera su
 * propia suscripción: el celular y la computadora se registran por separado
 * y ambos reciben.
 */
export async function activarPush(usuarioId: string, clavePublica: string) {
  if (!pushDisponible()) throw new Error('Este navegador no admite notificaciones push')

  const permiso = await Notification.requestPermission()
  if (permiso !== 'granted') {
    throw new Error('No se concedió el permiso. Se puede volver a habilitar desde los ajustes del navegador.')
  }

  const reg = await navigator.serviceWorker.ready
  const existente = await reg.pushManager.getSubscription()
  const sub = existente ?? await reg.pushManager.subscribe({
    userVisibleOnly: true,
    applicationServerKey: base64UrlABytes(clavePublica)
  })

  const json = sub.toJSON() as { endpoint: string; keys: { p256dh: string; auth: string } }
  const { error } = await supabase.from('push_suscripciones').upsert({
    usuario_id: usuarioId,
    endpoint: json.endpoint,
    p256dh: json.keys.p256dh,
    auth: json.keys.auth,
    user_agent: navigator.userAgent.slice(0, 200),
    activa: true
  }, { onConflict: 'endpoint' })
  if (error) throw error
}

export async function desactivarPush(usuarioId: string) {
  const reg = await navigator.serviceWorker.getRegistration()
  const sub = await reg?.pushManager.getSubscription()
  if (sub) {
    await supabase.from('push_suscripciones').delete()
      .eq('endpoint', sub.endpoint).eq('usuario_id', usuarioId)
    await sub.unsubscribe()
  }
}
